package uk.ac.bris.cs.scotlandyard.ui.model;

public enum  Side {

	MRX, DETECTIVE

}
