package uk.ac.bris.cs.scotlandyard.ui.controller;

import java.util.function.Consumer;

import javafx.scene.Parent;
import uk.ac.bris.cs.fxkit.Controller;
import uk.ac.bris.cs.scotlandyard.ui.ModelConfiguration;

public final class SavedConfigs implements Controller {

	public SavedConfigs(Consumer<ModelConfiguration> controller) {
		// TODO implement me
	}

	@Override
	public Parent root() {
		return null;
	}
}
